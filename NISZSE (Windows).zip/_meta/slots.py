def slotsFind():
    print("List Items: Here are The Items in Your Current Slots.")



def slotsID():
    print("ID List: Here are The Slot ID's")



def slotsEdit():
    print("Slot Editor: Here You Can Edit Your Currently Slotted Items.")